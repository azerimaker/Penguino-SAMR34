/**
* \file  conf_app.h
*
* \brief LORAWAN Demo Application include file
*		
*
* Copyright (c) 2018 Microchip Technology Inc. and its subsidiaries. 
*
* \asf_license_start
*
* \page License
*
* Subject to your compliance with these terms, you may use Microchip
* software and any derivatives exclusively with Microchip products. 
* It is your responsibility to comply with third party license terms applicable 
* to your use of third party software (including open source software) that 
* may accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, 
* WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, 
* INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, 
* AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE 
* LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL 
* LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE 
* SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE 
* POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY 
* RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, 
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*
* \asf_license_stop
*
*/
/*
* Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
*/

 

#ifndef APP_CONFIG_H_
#define APP_CONFIG_H_

/****************************** INCLUDES **************************************/

/****************************** MACROS **************************************/
/* Number of software timers */
#define TOTAL_NUMBER_OF_TIMERS            (25u)


/*Define the Sub band of Channels to be enabled by default for the application*/
#define SUBBAND 1
#if ((SUBBAND < 1 ) || (SUBBAND > 8 ) )
#error " Invalid Value of Subband"
#endif

/* Activation method constants */
#define OVER_THE_AIR_ACTIVATION           LORAWAN_OTAA
#define ACTIVATION_BY_PERSONALIZATION     LORAWAN_ABP

/* Message Type constants */
#define UNCONFIRMED                       LORAWAN_UNCNF
#define CONFIRMED                         LORAWAN_CNF

/* Enable one of the activation methods */
#define DEMO_APP_ACTIVATION_TYPE               OVER_THE_AIR_ACTIVATION
//#define DEMO_APP_ACTIVATION_TYPE               ACTIVATION_BY_PERSONALIZATION

/* Select the Type of Transmission - Confirmed(CNF) / Unconfirmed(UNCNF) */
#define DEMO_APP_TRANSMISSION_TYPE              UNCONFIRMED
//#define DEMO_APP_TRANSMISSION_TYPE            CONFIRMED

/* FPORT Value (1-255) */
#define DEMO_APP_FPORT                           1

/* Device Class - Class of the device (CLASS_A/CLASS_C) */
#define DEMO_APP_ENDDEVICE_CLASS                 CLASS_A
//#define DEMO_APP_ENDDEVICE_CLASS                 CLASS_C


/* ABP Join Parameters */
#define DEMO_DEVICE_ADDRESS                     0xDEADBEEF // tinyLora-01
#define DEMO_APPLICATION_SESSION_KEY            {0x7A, 0x9F, 0xF2, 0x4D, 0xC6, 0xA8, 0xC4, 0x31, 0xFB, 0xE3, 0x8B, 0x7C, 0x02, 0xE3, 0x85, 0x8B}
#define DEMO_NETWORK_SESSION_KEY                {0x49, 0x5B, 0x51, 0x21, 0x6A, 0x46, 0x3C, 0x3D, 0x4F, 0x1E, 0x5D, 0x7F, 0x73, 0xD1, 0x54, 0x84}


/* 
 Join Parameter */
// ttn otaa	
/*			    
#define DEMO_DEVICE_EUI                         {0x00, 0xBE, 0x34, 0xDA, 0x1D, 0x85, 0xE3, 0x51} //  tinylora-02
#define DEMO_APPLICATION_EUI                    {0x70, 0xB3, 0xD5, 0x7E, 0xD0, 0x01, 0x54, 0x35}
#define DEMO_APPLICATION_KEY                    {0x3D, 0x44, 0x87, 0x72, 0x41, 0x92, 0xAE, 0xC3, 0x09, 0x4C, 0x9D, 0x0D, 0x23, 0xCB, 0x68, 0x07}
*/

// ttn - tinylora-01							

#define DEMO_DEVICE_EUI                         {0x00, 0x13, 0x8D, 0xFE, 0x8F, 0xC4, 0x65, 0x87}
#define DEMO_APPLICATION_EUI                    {0x70, 0xB3, 0xD5, 0x7E, 0xD0, 0x01, 0x54, 0x35}
#define DEMO_APPLICATION_KEY                    {0xA9, 0x0D, 0x7A, 0xE0, 0xA0, 0xA6, 0x53, 0xCE, 0x2F, 0x80, 0xFD, 0x03, 0x5B, 0x64, 0xA2, 0xB5}



/* Multicast Parameters */
#define DEMO_APP_MCAST_ENABLE                   true
#define DEMO_APP_MCAST_GROUP_ADDRESS            0x0037CC56
#define DEMO_APP_MCAST_APP_SESSION_KEY          {0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6}
#define DEMO_APP_MCAST_NWK_SESSION_KEY          {0x3C, 0x8F, 0x26, 0x27, 0x39, 0xBF, 0xE3, 0xB7, 0xBC, 0x08, 0x26, 0x99, 0x1A, 0xD0, 0x50, 0x4D}

/* This macro defines the application's default sleep duration in milliseconds */
#define DEMO_CONF_DEFAULT_APP_SLEEP_TIME_MS     2000

#endif /* APP_CONFIG_H_ */

